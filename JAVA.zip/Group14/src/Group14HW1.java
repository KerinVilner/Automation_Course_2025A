import java.util.Vector;
import java.util.Scanner;

public class Group14HW1 {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {//THE CALCULATOR MENU
		int choice;
		boolean flag = true;
		System.out.println("welcome to our calculator, please select an option");
		do {
			System.out.println("0.Exit");
			System.out.println("1.Base 10 to 16");
			System.out.println("2.Base 16 to 10");
			choice = sc.nextInt();
			switch (choice) {
			case 1: {
				System.out.println("Please Select an Integar");
				int input = sc.nextInt();
				Returns16Base(input);
				System.out.println();
				break;
			}
			case 0: 
				flag = false;
				break;
				
			default:
				System.out.println("invalid input,please try again");
				break;
			}

		} while (flag);
		System.out.println("C U");
	}

	public static void Returns16Base(int x) {// RECIVES A NUMBER IN BASE 10 AND RETURNS THE NUMBER IN BASE 16
		boolean Negative = false;// TO CHECK IF THE RECIVED NUMBER IS NEGATIVE
		if (x < 0) {
			Negative = true;
			x = x * -1;
		}
		int ans = x;
		int Shaarit = 0;
		Vector<Integer> numbers = new Vector<>();// SAVE THE NUMBER IN A VECTOR

		while (ans >= 16) {// AS LONG AS THE NUMBER GREATER THAN 16 WE NEED TO DIVIDE HIM
			Shaarit = ans % 16;// TO SAVE THE REMAIN
			numbers.add(0, Shaarit);
			ans = ans / 16;// SAVE THE INTEGAR WITOUT THE REMAIN ROUNDED DOWN
		}
		numbers.add(0, ans);// IF THE NUMBER IS LOWER THAN 16
		if (Negative == true) {
			System.out.print("-");
		}
		for (int i = 0; i <= numbers.size() - 1; i++) {// LOOP TO RUN THROUGH ALL THE VECTOR AND PRINT ACCORDINGLY
			if (numbers.elementAt(i) < 10) {
				System.out.print(numbers.elementAt(i));
			} else if (numbers.elementAt(i) == 10) {
				System.out.print("A");

			} else if (numbers.elementAt(i) == 11) {
				System.out.print("B");

			} else if (numbers.elementAt(i) == 12) {
				System.out.print("C");
			} else if (numbers.elementAt(i) == 13) {
				System.out.print("D");
			} else if (numbers.elementAt(i) == 14) {
				System.out.print("E");
			} else if (numbers.elementAt(i) == 15) {
				System.out.print("F");

			}
		}
	}
}
