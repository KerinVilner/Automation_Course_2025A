import java.util.Vector;

public class Group14HW1 {

	public static void main(String[] args) {
		Returns16Base(-44);
	}

	public static void Returns16Base(int x) {
		boolean Negative=false;
		if (x<0) {
			Negative=true;
			x=x*-1;
		}
		int ans = x;
		int Shaarit = 0;
		Vector<Integer> numbers = new Vector<>();
		
		while (ans >= 16) {
			Shaarit = ans % 16;
			numbers.add(0,Shaarit);
			ans = ans / 16;

		}
		numbers.add(0,ans);
		if(Negative==true) {
			System.out.print("-");
		}
		for (int i = 0; i <= numbers.size() - 1; i++) {
			if (numbers.elementAt(i) < 10) {
				System.out.print(numbers.elementAt(i));
			} else if (numbers.elementAt(i) == 10) {
				System.out.print("A");

			} else if (numbers.elementAt(i) == 11) {
				System.out.print("B");

			} else if (numbers.elementAt(i) == 12) {
				System.out.print("C");
			} else if (numbers.elementAt(i) == 13) {
				System.out.print("D");
			} else if (numbers.elementAt(i) == 14) {
				System.out.print("E");
			} else if (numbers.elementAt(i) == 15) {
				System.out.print("F");

			}
		}
	}
}
